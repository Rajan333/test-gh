## Email Configuration

#### Step 1: Update and Install Packages
```sh
sudo apt-get update
sudo apt-get install postfix mailutils
```

#### Step 2: Configure Postfix
During installation, select "Internet Site" and set the system mail name to your domain name or server hostname.

####  Step 3: Postfix Configuration
Edit the Postfix configuration file:
```sh
sudo vim /etc/postfix/main.cf
Ensure the following settings are configured:
relayhost = [smtp.your-email-provider.com]:587
smtp_use_tls = yes
smtp_sasl_auth_enable = yes
smtp_sasl_security_options = noanonymous
smtp_sasl_password_maps = hash:/etc/postfix/sasl_passwd
```

#### Step 4: Set Up SASL Password
Create the /etc/postfix/sasl_passwd file:
```sh
sudo vim /etc/postfix/sasl_passwd
```
Add your email provider’s SMTP credentials:
```sh
[smtp.your-email-provider.com]:587 username:password
```

####  Step 5: Secure and Integrate Password File
```sh
sudo postmap /etc/postfix/sasl_passwd
sudo chown root:root /etc/postfix/sasl_passwd /etc/postfix/sasl_passwd.db
sudo chmod 600 /etc/postfix/sasl_passwd /etc/postfix/sasl_passwd.db
```

#### Step 6: Restart Postfix
```sh
sudo systemctl restart postfix
```

#### Step 7: Send a Test Email
```sh
echo "Test email body" | mail -s "Test email subject" recipient@example.com
```

This setup configures your Ubuntu server to send emails using Postfix and an external SMTP server. Make sure to replace placeholders with actual values.

### How to Get SMTP Credentials

To get SMTP credentials, you need to use an email service provider that supports SMTP for sending emails. Below are the steps for some common providers:

#### Gmail
1. Sign in to your Gmail account.
2. Go to Account Settings.
3. Enable "Less secure app access".
4. SMTP Server: smtp.gmail.com
5. SMTP Port: 587
6. Username: Your full Gmail email address.
7. Password: Your Gmail password (or App Password if 2FA is enabled).

#### Amazon SES
1. Sign in to AWS Management Console.
2. Navigate to Amazon SES.
3. Create SMTP Credentials in the SES console.
4. SMTP Server: Based on your AWS region (e.g., email-smtp.us-east-1.amazonaws.com).
5. SMTP Port: 587 or 465
6. Username: Generated SMTP username.
7. Password: Generated SMTP password.

#### SendGrid
1. Sign in to SendGrid.
2. Navigate to Settings > API Keys.
3. Create an API Key.
4. SMTP Server: smtp.sendgrid.net
5. SMTP Port: 587
6. Username: apikey
7. Password: Your SendGrid API key.

#### Mailgun
1. Sign in to Mailgun.
2. Navigate to Sending > Domains.
3. Select your domain and find SMTP settings.
4. SMTP Server: smtp.mailgun.org
5. SMTP Port: 587
6. Username: postmaster@your-domain
7. Password: Provided in your Mailgun account.
