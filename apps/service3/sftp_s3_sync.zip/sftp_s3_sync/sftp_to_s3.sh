#!/bin/bash
##__AUTHOR: RAJAN MIDDHA__##


#------------------------------------------------------------------------------#
#                                                                              #
#   This sctipt will connect to specfied sftp server, fetch specified files    #
#               and sync them into an s3 bucket                                #
#                                                                              #
#------------------------------------------------------------------------------#


# Variables
SFTP_HOST="127.0.0.1"
SFTP_PORT="22"
SFTP_USER="sftpuser"
SFTP_PASS="rajan"
REMOTE_DIR="$(date +'%m_%Y')" # Remote directory named mm-yyyy
LOCAL_DIR="/home/ubuntu/"
S3_BUCKET="sftp-s3-demo-bucket"
EMAIL_TO="middha.rajan@gmail.com"
EMAIL_SUBJECT="SFTP to S3 Sync Failed"

EMAIL_BODY="The SFTP to S3 sync operation has failed. Please check the server for more details."

# Create local directory if it doesn't exist
mkdir -p $LOCAL_DIR

# Install lftp if not installed
if ! command -v lftp &> /dev/null
then
    echo "lftp could not be found, installing..."
    sudo apt-get install lftp -y
fi

# Function to send email
send_failure_email() {
    echo $EMAIL_BODY | mail -s "$EMAIL_SUBJECT" $EMAIL_TO
}

# Connect to SFTP and download the entire directory
echo "Downloading the SFTP Directory...."
if ! lftp -u $SFTP_USER,$SFTP_PASS -e "mirror --verbose --delete $REMOTE_DIR $LOCAL_DIR; bye" sftp://$SFTP_HOST:$SFTP_PORT
then
    send_failure_email
    exit 1
else
    echo "Download Successfull"
fi

# Upload the entire directory to S3
echo "Syncing to SFTP"
if ! aws s3 sync "$REMOTE_DIR" "s3://$S3_BUCKET/$(date +'%m-%Y')/"
then
    send_failure_email
    exit 1
echo "Sync Successfull"
fi

rm -rf "$REMOTE_DIR"
echo "Directory has been successfully transferred from SFTP to S3." | mail -s "SFTP to S3 Sync: Success" $EMAIL_TO
